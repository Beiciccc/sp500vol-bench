# HPO 挑战者臂:最终实验规格(预注册稿 v1.0)

**骨架:方案 1(compute-first,评委三项最高分 0.82/0.85/0.88);嫁接方案 0 的 top-2 种子验证、manifest 防火墙、排除清单预注册、B 族免费网格,与方案 2 的 Track-B 组合钢人、val-fit/val-select 时间切分、覆盖率量化界、降级阶梯;并逐条修复三份裁决列出的全部缺陷。**

---

## 1)一句话定位

用一个**预注册、ASHA 调参、3 种子、双轨选择**的挑战者臂,把 R5 ml_methods concern #5("null 只是欠优化的产物")从 blocking 洞变成论文的正面证据句——无论调参后挑战者输赢,论文都拿到一条更强的 headline(预期 ΔP +0.03~0.05),同时顺带关闭 R3 的"loss 不对齐"与"Holm family 不可审计"两条 CRITICAL。

---

## 2)范围与搜索空间

### 2.1 入选模型(每个 spectrum 层级取固定配方下 val 最优代表 + 审稿人点名项)

| # | 模型 | 面板 | 目标参数化(stratum) | 搜索预算 | 覆盖界(95% 置信) |
|---|------|------|----------------------|---------|------------------|
| T1a | C2 FinBERT-S1 | long-form | levels(log-RV) | 32 Sobol 配置 | top-9% |
| T1b | C2 FinBERT-S1 | long-form | **firm-demeaned**(Δln RV vs firm 训练均值) | 16 配置(levels 优胜温启动) | top-17% |
| T1c | C2 FinBERT-S1 | event-driven | levels | 24 配置 | top-12% |
| T1d | C2 FinBERT-S1 | event-driven | firm-demeaned | 12 配置 | top-22% |
| T2 | C5 冻结 embedder heads(e5-mistral、gte-qwen2、qwen3 全部三个) | 双面板 | levels | ridge 闭式全网格 + MLP 48 随机 | 网格穷尽 |
| T3 | D2 gated fusion + D1 concat-MLP | 双面板 | levels | 各 48/32 随机 | top-6%/9% |
| T4 | C4 Longformer-4096 | 仅 long-form | levels | **16 配置 × {h=5, h=20} 独立搜索**,h=10 继承 h=5 优胜 | top-17% |
| T5 | B1/B2 TF-IDF/BoW ridge(含 delta-text 变体) | 双面板 | levels | CPU 全网格(α 13 点 × n-gram {1,1-2} × min_df {5,20,100} × sublinear-tf) | 穷尽 |

**修复"Longformer 是 token gesture"(两位评委共同点名):** T4 从 12 配置/仅 h=5/50% 子样,升级为 16 配置、全量训练集、且 **h=20(现有 -32.5% 的灾难 cell,调参 headroom 最可信的地方)独立搜索**。batch 经梯度累积实现等效 batch(声明等效性,修复 40GB 显存下 batch 128 的混杂问题)。

**修复"S1 入选循环论证"(方案 0 缺陷 1):** 预注册声明输入策略 S1–S4 是 benchmark 定义维度而非超参;**另加一个廉价补丁**——FinBERT long-form 优胜配置冻结后,以该配置单种子跑 S2/S3/S4 的 val 复核(≈14 A100-h);若某 S* 在 tuned 配置下 val 反超 S1,则该 S* 顶替进入 3 种子重训(切换规则预注册、只依赖 val)。event-driven 的 S 复核仅在 long-form 翻盘时条件触发。

**排除清单(预注册,每项一句理由):** C1/C3 被 FinBERT 在同层级同输入下全 cell 支配(C3 long-form 为 D9 领先时的预声明补跑项);B3/B4 字典法无实质超参(线性头并入 B 族网格);C6 prompted Qwen3-32B 无梯度训练参数,prompt 空间无界不搜,引用既有 elicitation-robustness 臂代偿,且 C6 是赢 cell 的臂,无人要求把它做强;D4 的可训练部件由 D1/D2 覆盖。

### 2.2 搜索空间(写入 `configs/hpo_arm.yaml`,commit 后零改动)

**T1/T4 共用 8 维:**
- lr:log-uniform [5e-6, 1e-4](包住固定配方 8e-5 与审稿人常引的 1e-5)
- head LR multiplier:{1, 10}
- weight decay:log-uniform [1e-4, 0.3]
- head:{linear, MLP-256-GELU};head dropout:{0.0, 0.1, 0.3}
- **层冻结:{全微调, 只调顶 4 层, 冻结编码器线性探针}**(直接回应"正则化/冻结能修过拟合")
- 有效 batch:{32, 128}(Longformer 经梯度累积)
- **训练目标:{MSE-on-log-RV, QLIKE-aligned(variance 尺度、softplus 输出、ε=1e-8 下限、梯度裁剪)}**——把 R3"训练用平方误差、评估用 QLIKE"的 CRITICAL 收进搜索空间内部解决
- epochs 不是搜索维度:≤15,val-fit QLIKE early stopping(patience 3),与固定配方同机制

**T2 C5 heads:** ridge α ∈ 10^{-3..5} 15 点 log 网格(闭式,CPU);MLP:深度 {1,2} × 宽度 {128,256,512} × dropout {0,0.1,0.3} × lr log-U[1e-4,1e-2] × wd {0,1e-4,1e-2} × 目标 {MSE, QLIKE}。
**T3 D2/D1:** 上表去层冻结,D2 加 gate 隐层 {64,128,256}、gate 初始化 {price-prior, uniform}、text-branch L2 {0,1e-4,1e-2}。

**量化覆盖界写进论文(方案 2 最佳想法):**"若存在能击败 HAR 的配置,它以 95% 置信占声明空间不足 9%(FinBERT long-form)"——诚实注明该界是采样层面的界,ASHA 晋升风险由加深的 rung(见 §3)缓解。

---

## 3)选择规则与防泄漏

### 3.1 ASHA(修复两份裁决共同点名的 rung-0 噪声缺陷)

- 算法:固定种子(sampler seed 2026)Sobol/随机采样 + 确定性 ASHA。**不用 BO/TPE**——零自适应实验者自由度,搜索本身可预注册。
- **Rung 改为 {2, 5, 15} epoch(Longformer {2, 5, 10}),η=3**(原方案 {1,4,12}/η=4 会系统性杀死 low-lr 全微调与冻结编码器等慢热配置——恰是审稿人假设优胜所在的区域;评委确认此改动约 +40% T1 搜索算力,可负担,见 §5)。
- 晋升指标:该 horizon 的 **vol-unit val-fit QLIKE**(与论文 primary 口径一致;variance-unit 只记录、绝不用于选择)。
- event-driven rung-0 用预声明的 30% 时序分层子样(子样只影响谁早死,绝不影响优胜者的最终训练数据)。
- 选择粒度:per (model × panel × stratum × horizon)——对挑战者严格更宽松,预注册写明"generosity 偏向挑战者"。

### 3.2 三层 val 切分 + top-2 种子验证(方案 2 + 方案 0 嫁接,互相修复对方缺陷)

- **val-fit(2020-01~2021-06):** rung 内晋升 + early stopping。
- **val-select(2021-07~2021-12):** 最终配置排序——对搜索期 early stopping 是 out-of-sample,封死"config 选择与 early stopping 双重使用同一 val"的反击。
- **top-2 种子验证(修复"val-select 仅 6 个月、单种子噪声主导"):** val-select 排名前 2 的配置各自以完整 3 种子重训(early stopping 按主协议用完整 val 窗,逐字节复用现有管线;此处对 val-select 的轻度信息复用如实披露——真正的防火墙在 test),优胜 = **3 种子 ensemble 的 val-select QLIKE 更低者**。种子噪声被 ensemble 平均掉,直接回应"48 张彩票"的攻击。Longformer 与 demeaned strata 取 top-1(声明:算力)。
- 平票规则预注册:先低 lr,再高 weight decay。
- **诊断件(必报):** 全体 max-rung trial 的 val-select→test rank correlation、winner vs median-config 的泛化差、winner 的 per-val-year 排名(披露 2020-21 含 COVID 的已知性质)。

### 3.3 双轨选择(方案 2 的核心资产,近乎免费嫁接)

同一 trial 池、两条机械 argmin、都预注册、都报告:
- **Track A(standalone):** argmin val-select 上模型 standalone QLIKE → 护卫 0/180 standalone null。
- **Track B(组合钢人),仅施加于 FinBERT-levels 双面板与 D2:** 对每个 max-rung trial,用现有 f_Ufirm 设计([1, log f_A2, log firm-mean-val-RV, log f_text],权重在 val-fit 上拟合),argmin val-select 上 QLIKE(f_Ufirm) − QLIKE(f_Rfirm)——**把挑战者直接对着 firm-identity-augmented reference 优化**。若它仍过不了 identity+pool 门,"a tuned challenger could have won"的界收到最紧。Track B 优胜若与 Track A 相同则合并重训(预算按不合并计上界)。

### 3.4 防泄漏边界

- HPO harness 消费的数据 manifest **物理不含** test 2022-25 的特征与标签,每 trial 记录 manifest hash(方案 0:"我们不可能偷看"成为可验证的基础设施而非口头声明)。
- 条件重训规则(只依赖 val,预注册):Longformer 与 demeaned strata 仅当 tuned val 优于固定配方 val 时才做 3 种子全量重训;否则报告"val 无 headroom,固定配方维持"。
- **预注册工件(修复"自签 git tag"缺陷):** `configs/hpo_arm.yaml` + 设计文档在任何 test 评估前 (a) git tag 带日期提交、hash 印入论文,(b) **同步做 OSF 匿名化注册(anonymized view-only link,兼容双盲)**——外部时间戳,不再是"作者同时掌握时钟和先验"。
- **QLIKE loss 工程风险(两份裁决点名):** D0-D1 专门排 harness 构建日,QLIKE loss 带单元测试(数值稳定性、variance→log-space 转换进重校准管线的正确性),2-trial 端到端冒烟先行;预注册 fallback——若某 cell 的 QLIKE-loss trial >30% NaN/发散,该 cell 的 loss 维度坍缩回 MSE 并如实报告(val-only 决策,非 fork)。

---

## 4)种子与进协议的方式

- **搜索期:** 单种子 2026(预注册,绝不事后换;ASHA 文献标准做法,种子噪声由 top-2 验证与重训吸收)。
- **终跑:** 每个优胜配置从头以 3 种子(2026/2027/2028)重训,**primary = seed-ensemble(三种子 log-forecast 均值)**,与 A2/C/D 各臂定义逐字一致;per-seed 进附录。
- **进协议零新代码路径:** tuned 模型产出的就是新的 `results/runs/` 目录,直接喂进现有 `forecast_combination.py` 泄漏安全 log-space 重校准 → reference interval(单一重校准 HAR 上界 / firm-identity 下界)→ 最大价格池 → label-shuffle + within-date placebo → day-clustered DM(HAC lag h−1, HLN)→ Holm。
- **Placebo 硬门(对 Track B 尤其):** Track-B 优胜是被"对着组合目标选出来"的,最有动机学 identity 捷径——其 seed-ensemble 必须先过双 placebo 才有资格进任何胜出计数;失败即记 artefact,预注册写死。这是论文自己的方法论对文本最有利的臂的对称施加。
- **多重性:** 原 180/69 family 冻结不动、分母不变;tuned 臂自成预注册 Holm family(cell 全枚举表进 yaml:standalone ≈51 项 + cascade ≈51 项 + Track-B ≤12 项);另报一个 primary+tuned 联合 Holm 作 sensitivity。
- 既有单种子 tuned 臂(lr + early stopping)降级为 **pilot**,预注册中公开披露其已接触 test 的 null 结果及偏差方向论证:先验 null 只会降低我们跑更多 HPO 的动机,不会把空间塑形向 null;新空间严格包含 pilot 空间并新增审稿人点名的全部维度(冻结、decay、head、QLIKE 目标)。隐瞒它才是真正的 forking path。

---

## 5)算力排期表

**两套锚点并列(修复"单项估计无审计余量"):** 上界 = 任务书口径(FinBERT-LF 0.2 A100-h/horizon-epoch、全跑 1.5 h/horizon/seed;ED ×2.5;Longformer ×5);下界 = 实测 cost.json(FinBERT-LF 全跑 1.14 h/seed、ED 1.53、Longformer 18.7、D2 0.6),约为上界 1/3。**预算按上界排,富余按下界看。**

| 项目 | A100-h(上界) | 备注 |
|---|---|---|
| T1a FinBERT-LF levels 搜索(32 配置, rungs 2/5/15) | 79 | ≈131 epoch-units/horizon ×3×0.2 |
| T1b LF demeaned 搜索(16) | 39 | |
| T1c FinBERT-ED levels 搜索(24, rung0 30% 子样) | 98 | |
| T1d ED demeaned 搜索(12) | 48 | |
| T4 Longformer 搜索(16 × {h5, h20}, rungs 2/5/10) | 114 | h10 继承 h5 优胜 |
| T2 C5 MLP heads(3 embedder × 2 面板 × 48) | 30 | 显式预算,含 ASHA-free 全 epoch 训练审计余量 |
| T3 D2+D1 heads(2×2 面板) | 40 | |
| T5 B 族 + C5 ridge 全网格 | 0(CPU) | box cgroup 配额内吃满,与 GPU 并行 |
| top-2 3 种子验证重训:FinBERT LF 27 + ED 66 + D2/D1/C5 14 | 107 | |
| 条件重训(val-gated):demeaned LF+ED 47 + Longformer 60 | 107 | 仅 val 有 headroom 才触发 |
| Track-B 额外重训(优胜与 Track-A 不同才发生,≤4 cell) | 60 | |
| S2-S4 val 复核(LF, 优胜配置, 单种子) | 14 | ED 复核条件触发 |
| test 单次评估 + cascade/DM/Holm/placebo 重算 | 15 | +CPU |
| **合计** | **≈750(上界)/ ≈260(实测口径)** | 可用 4×A100×12 天 ≈ 1150 h → **利用率 65%(最坏)/ ~23%(常态)** |

**日程(D0 = 7/13;box 前 1 天被 Yelp 占用):**
- **D0–D1(7/13–14):** Yelp 收尾并行——harness 构建(扩展 run_matrix 为异步 ASHA 调度)+ QLIKE loss 单元测试 + 2-trial 端到端冒烟;预注册 yaml 落 git tag + OSF 匿名注册。**明确排 1.5 个工程日,修复"排程假定代码一次写对"的缺陷。**
- **D1.5–D4:** T1a/T1b 搜索(2 GPU)‖ T5/C5-ridge CPU 网格 ‖ T2/T3 heads 插空。
- **D3–D6:** T1c/T1d(2 GPU)+ T4(2 GPU)。
- **D6–D8:** top-2 种子验证重训 + S 复核 + 条件重训 + Track-B 增量重训。
- **D8(7/21,abstract 截止日):** test 单次评估 + cascade 重算——**判决落在 abstract 当天**,abstract 用双版本措辞(见 §7)。
- **D9–D10:** 表格与论文整合,**7/23 数字冻结**;D9 若领先才触发 C3 RoBERTa 补跑。
- **D11–D15(7/24–28):** ≥4 天 buffer,可吸收任意一臂的整跑重来或翻车改写。

**预注册降级阶梯(只看墙钟、不看结果,降级不构成 fork):** ① Longformer h=20 搜索砍掉、改由 h=5 优胜迁移;② ED demeaned stratum 砍掉、demeaned 仅保 LF;③ D1 砍掉、fusion 由 D2 代表。

---

## 6)论文落点

1. **§4 "comparability, not per-model tuning" 句尾加前向引用:**"…complemented by a pre-registered, externally time-stamped HPO arm (§X) that tests whether this design choice manufactures the null."
2. **主文新表(~0.4 页)"Pre-registered tuned-challenger arm":** 行 = tuned (model × panel × stratum),列 = 固定配方 QLIKE / Track-A tuned / Track-B tuned、**val-headroom(tuned val − fixed val)**、vs HAR standalone 判定、cascade(recalibrated-HAR / identity / maximal-pool)判定、placebo、覆盖界。每个 cell 无论输赢必入表。
3. **headline 改写:**"0/180 under the comparability recipe **and 0/N under a pre-registered ASHA-tuned, multi-seed arm — including challengers selected directly against the identity-augmented combination objective**"(若维持 null);cascade 句(38/69→0/69)注明 tuned Track-B 同样 0/N;contribution 3("neither scale nor domain adaptation lifts text")改引 tuned FinBERT/Longformer/C5 cell。
4. **abstract 加一个从句**,其余不动。
5. **tuned firm-demeaned FinBERT cell 在 identity-confound 小节单独一句**——它是唯一同时回答 W1(under-tuned)与 W2(levels-only objective)的 cell,无论过不过 identity reference 都报告。
6. **若 val-headroom ≤ 0:** 本身作为证据句——"validation headroom is ≤0 in k/N cells: the fixed recipe was not the binding constraint."
7. **附录 X:** yaml 全文 + git hash + OSF 链接、ASHA 全轨迹、trial 全表(config/val-fit/val-select/test)、val→test rank correlation、per-seed 表、pilot 披露、Holm family 枚举表(顺带关闭 R3"family 不可审计"CRITICAL)。

---

## 7)翻车预案

- **(A)tuned 仍 0 胜(先验最可能:pilot 5/9 cell 更差、过拟合诊断意味着调参主要加正则、向 HAR 收缩):** null 从"配方的产物"升级为"对 lr × decay × 冻结 × head × 目标 的预注册搜索不敏感,且组合钢人轨道也失败",R5 concern #5 关闭,ΔP +0.03~0.05 兑现。
- **(B)tuned 胜过单一重校准 HAR、但死在 identity+pool 门:** 非翻车——这是论文 38/69→0/69 主线现场重演,"连对着强 reference 优化出的挑战者的增益也被 identity 复现"是 shortcut 论点的最强新证,headline 零改动。
- **(C)Track-B 优胜穿过 identity+pool 且过双 placebo:** headline null 死,论文不死——benchmark(贡献 1)与 reference-interval 协议(贡献 2)结果无关;叙事转为"协议第一次裁决出一个真效应,且它需要对着强 reference 调参才浮现",顺带给 R3 另一条 CRITICAL(cascade 从无 sensitivity 证明)提供正面证据,与既有 C6 8-K bounded-residual 叙事同构。对 AAAI 这是更好卖的正结果。
- **日程保险:** test 判决 D8(7/21)落地,距全文截止 ≥7 天;**abstract 双版本(null-holds / survivor-found)在 D8 前预写完毕**——唯一不可发表的情形("abstract 锁死 null 框架后才发现 (C)")被构造排除。
- **唯一真坏情形是结果晚于 7/23 数字冻结:** 由 65% 上界利用率 + 降级阶梯 + 4 天 buffer 控制,不由实验设计承担。

---

## 8)明确不做什么(防 forking-paths,全部写入预注册)

1. **不搜 C6 prompt 空间**(无界 fork;引用既有 elicitation-robustness 臂)。
2. **不做 S 策略全矩阵重搜**——只做优胜配置下的 val 复核(切换规则预注册)。
3. **不改数据窗口、面板定义、split、评估指标**——它们是 benchmark 定义。
4. **不事后加宽搜索空间**——空间在声明时刻已刻意放宽(包住 8e-5 与 1e-5、含冻结与 QLIKE 目标),之后零改动;崩溃/OOM 强制的偏离逐条记录并原样报告。
5. **不用自适应搜索算法**(BO/TPE)——固定种子采样 + 确定性晋升,搜索本身无实验者自由度。
6. **test 只接触一次**,每个终跑 cell 的 test 评估不可撤回、不得事后剔除;harness 物理不含 test(manifest hash 逐 trial 可审)。
7. **不回溯改原 Holm family**——原 69/180 分母冻结;tuned 臂自成 family;不从新臂挑单点讲故事(全 cell 入表)。
8. **不隐藏 pilot**——单种子 tuned 臂及其 test null 公开披露并给出偏差方向论证。
9. **不给 Track-B 优胜豁免任何门**——placebo + identity reference 对称硬施加。
10. **两条选择轨道都报告**——不存在"事后选对自己有利的那条轨"的自由度。

---

Judge scores: [{"angle": "reviewer-first", "acc": 0.8, "feas": 0.75, "safe": 0.85}, {"angle": "compute-first", "acc": 0.82, "feas": 0.85, "safe": 0.88}, {"angle": "inference-first", "acc": 0.8, "feas": 0.72, "safe": 0.88}]